window.addEventListener('scroll', ()=> {

    const scrolled= window.scrollY;

    console.log(scrolled);

    if (scrolled>100)
    {
        document.getElementById('popupic').classList.add('aktiv');
    }

    else {
        document.getElementById('popupic').classList.remove('aktiv');
    }

    if (scrolled>600)
    {
        document.getElementById('backtotop').classList.add('aktiv');
    }

    else {
        document.getElementById('backtotop').classList.remove('aktiv');
    }

})