<?php session_start();?>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<header>

<img src="slike/logo.png" alt="">

</header>
	<nav class="container">

		<img id="popupic" src="slike/logo.png" alt="">
		<ul>
	
			<li><a href="index.php">NASLOVNA</a></li>
			<li ><a href="sport.php">SPORT</a></li>
			<li><a href="kultura.php">KULTURA</a></li>
			<?php
			if (isset($_SESSION['$razina']) && $_SESSION['$razina'] == '1') {
			
				echo '<li class="unos"><a href="unos.php">UNOS</a></li>';
				echo '<li class="admin"><a href="admin.php">ADMIN</a></li>';
			}
			?>

		</ul>

		<ul>

		<?php 
			if (isset($_SESSION['$korisnicko_ime'])) {

				echo $_SESSION['$korisnicko_ime'];
				echo '<li class="logout"><a href="logout.php">Logout</a></li>';

			} else {
				echo '<li class="login"><a href="login.php">Login</a></li>';
				echo '<li class="registracija"><a href="register.php">Registracija</a></li>';
			}

			?>
		
		</ul>
	</nav>
	<a href='#'><img src="slike/arrowup.png" alt="" id="backtotop"></a>
	<script src='animacije.js'></script>
	<script>

const activePage= window.location.pathname;
        
        console.log(activePage);
		const navLinks = document.querySelectorAll('nav a').forEach(link => {
			if(link.href.includes(`${activePage}`))
		{
			link.classList.add('active');
		}	
		})


	</script>

	<script src='animacije.js'></script>

