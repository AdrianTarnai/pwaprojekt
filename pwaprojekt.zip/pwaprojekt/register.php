



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Akshar:wght@300&family=Kdam+Thmor+Pro&family=Roboto+Flex:opsz,wght@8..144,200;8..144,300;8..144,400;8..144,500;8..144,900&display=swap" rel="stylesheet">

</head>
<?php require_once "./header.php" ?>


<body>
            <section>
            <form method="post" action="registracija.php" enctype="multipart/form-data">
            <p>IME</p>
            <input id="ime" name="ime" type="text">
            <span id="imewarning"></span>
            <br>
            <br>
            <p>PREZIME</p>
            <input id="prezime" name="prezime" type="text">
            <span id="prezimewarning"></span>
            <br>
            <br>
            <p>USERNAME</p>
            <input id="username" name="username"type="text">
            <span id="usernamewarning"></span>
            <br>
            <br>
            <p>PASSWORD</p>
            <input id="password" name="password"type="password">
            <span id="passwordwarning"></span>
            <p>PONOVI PASSWORD</p>
            <input id="password2" name="password2"type="password">
            <span id="passwordwarning2"></span>
            <br>
            <br>
            <input id="submit" type="submit" value='registriraj se' name="submit">
            </form>




            </section>

            <script>
    document.getElementById('submit').onclick = function(event)

{

    if(document.getElementById('ime').value=='')

    {
        event.preventDefault();
        document.getElementById('ime').style.border= '2px solid green';
        document.getElementById('imewarning').innerHTML='<br>Niste unijeli ime';
    }
    if(document.getElementById('prezime').value=='')

{
    event.preventDefault();
    document.getElementById('prezime').style.border= '2px solid green';
    document.getElementById('prezimewarning').innerHTML='<br>Niste unijeli prezime';
}
    if(document.getElementById('username').value=='')

    {
        event.preventDefault();
        document.getElementById('username').style.border= '2px solid green';
        document.getElementById('usernamewarning').innerHTML='<br>Niste unijeli username';
    }

    if(document.getElementById('password').value=='')

    {
        event.preventDefault();
        document.getElementById('password').style.border= '2px solid green';
        document.getElementById('passwordwarning').innerHTML='<br>Niste unijeli password';
    }
      if(document.getElementById('password2').value=='')

    {
        event.preventDefault();
        document.getElementById('password2').style.border= '2px solid green';
        document.getElementById('passwordwarning2').innerHTML='<br>Niste unijeli password';
    }

    if (document.getElementById('password2').value != document.getElementById('password').value)
    {
        event.preventDefault();
        document.getElementById('passwordwarning2').innerHTML='<br>Krivo unesen ponovni password';
    }
}
            </script>
</body>
</html>